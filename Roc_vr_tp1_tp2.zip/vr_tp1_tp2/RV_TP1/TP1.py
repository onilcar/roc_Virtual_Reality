import numpy as np
from numpy.linalg import svd
import pandas as pd


# Définir le nombre de points.
def EntrerPoint():
    M = input("Veuillez entrer le nombre de points necéssaire: ")
    M = int(M)
    P = np.empty((M,3))
    print("Veuillez entrer les coordonnées de chaque point : ")
    for j in range (M):
        P[j][0] = input("x :")
        P[j][1] = input("y :")
        P[j][2] = input("z :")
   # print(P)
    return P

def DefinirMatrix():
    n = 3
    m = int(input("Veuillez entrer le nombre de colonnes: "))
    a = [[1] * m for i in range(n)]

    for i in range(n):
       for j in range(m):
            a[i][j] = int(input())

    M = np.matrix(a)
    return M

# Calcul de Centroide
def CreerCentroid (M):
    return np.mean(M, axis=0)

# Calcul de la Covariance de la Matrice M
def MatriceCovariance(P1, C1, P2, C2):
    row, col = P1.shape # Défition de la matrice avec colonne et ligne
    S = np.zeros(P1.shape)
    for i in range (col):
        P1C1_t = (P1[i] - C1).transpose()
        print(P1C1_t)
        S = S + (P1C1_t*(P2[i] - C2))
    return S
def TransposeMatrice(P1):
    P1_t = P1.transpose()
    return P1_t
# Exécution des fonctions
def main():
    #Q = MatriceCovariance()
    #print(Q)
    P1 = EntrerPoint()
    print(P1.transpose())
    exit(0)
    C1 = CreerCentroid(P1)
    print("----------------------")
    #Q1 = TransposeMatrice(P1)
    #print(Q1)
    #exit(0)
    P2 = EntrerPoint()
    C2 = CreerCentroid(P1)
    print(C2)
    H = MatriceCovariance(P1, C1, P2, C2)
    print(H)

if __name__ == '__main__':
    main()
